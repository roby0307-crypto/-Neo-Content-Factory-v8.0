import { useState } from "react";
import { Sidebar } from "./components/Sidebar";
import { DashboardView } from "./views/DashboardView";
import { QuotesView } from "./views/QuotesView";
import { VideosView } from "./views/VideosView";
import { SettingsView } from "./views/SettingsView";
import { QuickStartView } from "./views/QuickStartView";

export function App() {
  const [currentView, setCurrentView] = useState("dashboard");

  const renderView = () => {
    switch (currentView) {
      case "dashboard":
        return <DashboardView />;
      case "quotes":
        return <QuotesView />;
      case "videos":
        return <VideosView />;
      case "settings":
        return <SettingsView />;
      case "quickstart":
        return <QuickStartView />;
      default:
        return <DashboardView />;
    }
  };

  return (
    <div className="flex min-h-screen bg-slate-50">
      <Sidebar currentView={currentView} setCurrentView={setCurrentView} />
      <main className="flex-1 ml-64 p-8 overflow-y-auto h-screen">
        <div className="max-w-6xl mx-auto">
          {renderView()}
        </div>
      </main>
    </div>
  );
}
