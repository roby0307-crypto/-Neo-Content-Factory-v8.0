import { Terminal, Download, FileJson, CheckCircle } from "lucide-react";

export function QuickStartView() {
  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div>
        <h2 className="text-3xl font-bold text-slate-800 mb-2">Quick Start Guide</h2>
        <p className="text-slate-600 text-lg">The "One-Click" Method to get your auto-poster running.</p>
      </div>

      <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6 space-y-8">
        
        {/* Prerequisites */}
        <section>
          <h3 className="text-xl font-bold text-slate-800 flex items-center gap-2 mb-4 border-b border-slate-100 pb-2">
            <CheckCircle className="w-5 h-5 text-indigo-500" />
            1. Prerequisites
          </h3>
          <p className="text-slate-600 mb-4">Ensure you have the following installed on your system:</p>
          <ul className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <li className="flex items-start gap-3 p-4 bg-slate-50 rounded-lg border border-slate-100">
              <div className="p-2 bg-white rounded shadow-sm shrink-0">
                <Terminal className="w-5 h-5 text-slate-700" />
              </div>
              <div>
                <strong className="block text-slate-800">Python 3.9+</strong>
                <span className="text-sm text-slate-500">Core runtime</span>
              </div>
            </li>
            <li className="flex items-start gap-3 p-4 bg-slate-50 rounded-lg border border-slate-100">
              <div className="p-2 bg-white rounded shadow-sm shrink-0">
                <Terminal className="w-5 h-5 text-slate-700" />
              </div>
              <div>
                <strong className="block text-slate-800">FFmpeg</strong>
                <span className="text-sm text-slate-500">Required for video rendering</span>
              </div>
            </li>
            <li className="flex items-start gap-3 p-4 bg-slate-50 rounded-lg border border-slate-100">
              <div className="p-2 bg-white rounded shadow-sm shrink-0">
                <Terminal className="w-5 h-5 text-slate-700" />
              </div>
              <div>
                <strong className="block text-slate-800">ImageMagick</strong>
                <span className="text-sm text-slate-500">Required for text rendering</span>
              </div>
            </li>
          </ul>
        </section>

        {/* Setup */}
        <section>
          <h3 className="text-xl font-bold text-slate-800 flex items-center gap-2 mb-4 border-b border-slate-100 pb-2">
            <Download className="w-5 h-5 text-indigo-500" />
            2. Setup
          </h3>
          <ol className="list-decimal list-inside space-y-4 text-slate-600 ml-2">
            <li>Download/Clone this repository to your computer.</li>
            <li>Open your terminal or command prompt in the folder.</li>
            <li>Run the launcher script:</li>
          </ol>
          <div className="mt-4 bg-slate-900 rounded-lg p-4 font-mono text-sm text-slate-300 relative group">
            <button className="absolute right-2 top-2 px-2 py-1 bg-white/10 hover:bg-white/20 rounded text-xs text-white opacity-0 group-hover:opacity-100 transition-opacity">
              Copy
            </button>
            <code>python setup_and_run.py</code>
          </div>
        </section>

        {/* Configuration */}
        <section>
          <h3 className="text-xl font-bold text-slate-800 flex items-center gap-2 mb-4 border-b border-slate-100 pb-2">
            <FileJson className="w-5 h-5 text-indigo-500" />
            3. Configuration
          </h3>
          <ul className="space-y-3 text-slate-600 list-disc list-inside ml-2">
            <li>The script will create a <code className="bg-slate-100 px-1 py-0.5 rounded text-sm text-indigo-600">.env</code> file. Open it and paste your API keys for OpenAI and ElevenLabs.</li>
            <li>Place at least one <code className="bg-slate-100 px-1 py-0.5 rounded text-sm text-indigo-600">.ttf</code> font file in <code className="bg-slate-100 px-1 py-0.5 rounded text-sm text-slate-800">assets/fonts/</code>.</li>
            <li>Place a few background <code className="bg-slate-100 px-1 py-0.5 rounded text-sm text-indigo-600">.mp3</code> tracks in <code className="bg-slate-100 px-1 py-0.5 rounded text-sm text-slate-800">assets/music/</code>.</li>
          </ul>
        </section>

        {/* How to Use */}
        <section>
          <h3 className="text-xl font-bold text-slate-800 mb-4 border-b border-slate-100 pb-2">
            📊 How to Use
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-indigo-50 p-5 rounded-lg border border-indigo-100">
              <h4 className="font-bold text-indigo-900 mb-2">Manual Mode</h4>
              <p className="text-sm text-indigo-800">
                Use this dashboard to generate a single video manually and preview the AI prompts before rendering.
              </p>
            </div>
            <div className="bg-emerald-50 p-5 rounded-lg border border-emerald-100">
              <h4 className="font-bold text-emerald-900 mb-2">Auto Mode</h4>
              <p className="text-sm text-emerald-800">
                Keep the <code className="bg-emerald-200/50 px-1 py-0.5 rounded">scheduler.py</code> running in the background. It will check your database and post a new video every day at your specified time.
              </p>
            </div>
          </div>
        </section>

        {/* License */}
        <section className="bg-slate-50 p-6 rounded-lg border border-slate-200 text-center">
          <p className="text-slate-600 text-sm mb-2">
            <strong>⚖️ License & Disclaimer:</strong> This project is for educational and content creation purposes. Please ensure you comply with the Terms of Service of YouTube and TikTok regarding automated posting.
          </p>
          <p className="font-medium text-slate-800">Happy Automating! 🚀</p>
        </section>
      </div>
    </div>
  );
}
