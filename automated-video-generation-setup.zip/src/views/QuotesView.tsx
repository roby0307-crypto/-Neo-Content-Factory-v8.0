import { useState } from "react";
import { Plus, Search, Edit2, Trash2 } from "lucide-react";

export function QuotesView() {
  const [quotes] = useState([
    { id: 1, text: "The only limit to our realization of tomorrow is our doubts of today.", author: "Franklin D. Roosevelt", status: "Used" },
    { id: 2, text: "Do not wait to strike till the iron is hot, but make it hot by striking.", author: "William Butler Yeats", status: "Pending" },
    { id: 3, text: "Whether you think you can or you think you can't, you're right.", author: "Henry Ford", status: "Pending" },
    { id: 4, text: "I have not failed. I've just found 10,000 ways that won't work.", author: "Thomas A. Edison", status: "Used" },
    { id: 5, text: "A person who never made a mistake never tried anything new.", author: "Albert Einstein", status: "Pending" },
  ]);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <h2 className="text-2xl font-bold text-slate-800">Quotes Database</h2>
        <div className="flex w-full sm:w-auto items-center gap-4">
          <div className="relative flex-1 sm:flex-none">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input 
              type="text" 
              placeholder="Search quotes..." 
              className="w-full sm:w-64 pl-10 pr-4 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>
          <button className="flex items-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg font-medium transition-colors whitespace-nowrap">
            <Plus className="w-4 h-4" />
            Add Quote
          </button>
        </div>
      </div>

      <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-sm text-slate-500 font-medium">
                <th className="p-4 w-16 text-center">ID</th>
                <th className="p-4">Quote Text</th>
                <th className="p-4 w-48">Author</th>
                <th className="p-4 w-32">Status</th>
                <th className="p-4 w-24 text-center">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {quotes.map((quote) => (
                <tr key={quote.id} className="hover:bg-slate-50 transition-colors group">
                  <td className="p-4 text-center text-slate-500">#{quote.id}</td>
                  <td className="p-4">
                    <p className="text-slate-800 font-medium line-clamp-2">"{quote.text}"</p>
                  </td>
                  <td className="p-4 text-slate-600">{quote.author}</td>
                  <td className="p-4">
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                      quote.status === 'Used' 
                        ? 'bg-slate-100 text-slate-800' 
                        : 'bg-emerald-100 text-emerald-800'
                    }`}>
                      {quote.status}
                    </span>
                  </td>
                  <td className="p-4 text-center">
                    <div className="flex items-center justify-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button className="p-1.5 text-slate-400 hover:text-indigo-600 rounded hover:bg-indigo-50 transition-colors">
                        <Edit2 className="w-4 h-4" />
                      </button>
                      <button className="p-1.5 text-slate-400 hover:text-red-600 rounded hover:bg-red-50 transition-colors">
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="p-4 border-t border-slate-200 bg-slate-50 flex items-center justify-between text-sm text-slate-500">
          <p>Showing 1 to {quotes.length} of 248 quotes</p>
          <div className="flex items-center gap-2">
            <button className="px-3 py-1 border border-slate-200 rounded bg-white hover:bg-slate-50 disabled:opacity-50">Previous</button>
            <button className="px-3 py-1 border border-slate-200 rounded bg-white hover:bg-slate-50">Next</button>
          </div>
        </div>
      </div>
    </div>
  );
}
