import { Play, Download, Trash2, Eye, Calendar, Film } from "lucide-react";

export function VideosView() {
  const videos = [
    { id: 1, title: "Quote_Vid_1024.mp4", date: "Today, 10:00 AM", duration: "0:15", status: "Posted" },
    { id: 2, title: "Quote_Vid_1025.mp4", date: "Tomorrow, 10:00 AM", duration: "0:14", status: "Scheduled" },
    { id: 3, title: "Quote_Vid_1026.mp4", date: "Wed, 10:00 AM", duration: "0:18", status: "Ready" },
    { id: 4, title: "Quote_Vid_1027.mp4", date: "Thu, 10:00 AM", duration: "0:12", status: "Draft" },
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-slate-800">Video Previews</h2>
        <button className="flex items-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg font-medium transition-colors">
          <Play className="w-4 h-4" fill="currentColor" />
          Generate New Manual Video
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {videos.map((video) => (
          <div key={video.id} className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-sm hover:shadow-md transition-shadow">
            <div className="aspect-[9/16] bg-slate-900 relative group flex items-center justify-center">
              <Film className="w-12 h-12 text-slate-600" />
              <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-4">
                <button className="p-3 bg-white/20 hover:bg-white/30 rounded-full backdrop-blur-sm text-white transition-colors">
                  <Play className="w-6 h-6" fill="currentColor" />
                </button>
                <button className="p-3 bg-white/20 hover:bg-white/30 rounded-full backdrop-blur-sm text-white transition-colors">
                  <Eye className="w-6 h-6" />
                </button>
              </div>
              <div className="absolute bottom-2 right-2 px-2 py-1 bg-black/60 rounded text-xs text-white font-medium backdrop-blur-sm">
                {video.duration}
              </div>
            </div>
            
            <div className="p-4">
              <div className="flex justify-between items-start mb-2">
                <h3 className="font-semibold text-slate-800 truncate pr-2">{video.title}</h3>
                <span className={`px-2 py-0.5 rounded text-xs font-medium whitespace-nowrap ${
                  video.status === 'Posted' ? 'bg-emerald-100 text-emerald-800' :
                  video.status === 'Scheduled' ? 'bg-amber-100 text-amber-800' :
                  video.status === 'Ready' ? 'bg-blue-100 text-blue-800' :
                  'bg-slate-100 text-slate-800'
                }`}>
                  {video.status}
                </span>
              </div>
              
              <div className="flex items-center gap-2 text-sm text-slate-500 mb-4">
                <Calendar className="w-4 h-4" />
                <span>{video.date}</span>
              </div>
              
              <div className="flex items-center justify-between border-t border-slate-100 pt-4">
                <button className="flex items-center gap-2 text-sm font-medium text-slate-600 hover:text-indigo-600 transition-colors">
                  <Download className="w-4 h-4" />
                  Download
                </button>
                <button className="p-1.5 text-slate-400 hover:text-red-600 rounded hover:bg-red-50 transition-colors">
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
