import { 
  Play, 
  Database, 
  Video, 
  CheckCircle,
  Clock
} from "lucide-react";

export function DashboardView() {
  const stats = [
    { title: "Total Quotes", value: "248", icon: Database, color: "text-blue-500", bg: "bg-blue-100" },
    { title: "Videos Generated", value: "1,420", icon: Video, color: "text-indigo-500", bg: "bg-indigo-100" },
    { title: "Successfully Posted", value: "1,418", icon: CheckCircle, color: "text-emerald-500", bg: "bg-emerald-100" },
    { title: "Next Scheduled Post", value: "2h 15m", icon: Clock, color: "text-amber-500", bg: "bg-amber-100" }
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-slate-800">Dashboard</h2>
        <button className="flex items-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg font-medium transition-colors">
          <Play className="w-4 h-4" fill="currentColor" />
          Generate Video Now
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, i) => (
          <div key={i} className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm flex items-center gap-4">
            <div className={`p-4 rounded-lg ${stat.bg}`}>
              <stat.icon className={`w-6 h-6 ${stat.color}`} />
            </div>
            <div>
              <p className="text-sm font-medium text-slate-500">{stat.title}</p>
              <p className="text-2xl font-bold text-slate-800">{stat.value}</p>
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6">
          <h3 className="text-lg font-semibold text-slate-800 mb-4">Recent Generations</h3>
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="flex items-center gap-4 p-4 border border-slate-100 rounded-lg hover:bg-slate-50">
                <div className="w-16 h-16 bg-slate-200 rounded-md overflow-hidden flex-shrink-0 relative">
                  <div className="absolute inset-0 flex items-center justify-center">
                    <Video className="w-6 h-6 text-slate-400" />
                  </div>
                </div>
                <div className="flex-1 min-w-0">
                  <h4 className="font-medium text-slate-800 truncate">Quote_Vid_{i}.mp4</h4>
                  <p className="text-sm text-slate-500">Rendered {(i * 2)} hours ago</p>
                </div>
                <span className="px-3 py-1 bg-emerald-100 text-emerald-700 text-xs font-medium rounded-full">Posted</span>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6">
          <h3 className="text-lg font-semibold text-slate-800 mb-4">System Status</h3>
          <div className="space-y-6">
            <div>
              <div className="flex justify-between text-sm mb-2">
                <span className="font-medium text-slate-700">OpenAI API Connection</span>
                <span className="text-emerald-600 font-medium">Connected</span>
              </div>
              <div className="w-full bg-slate-100 rounded-full h-2">
                <div className="bg-emerald-500 h-2 rounded-full" style={{ width: '100%' }}></div>
              </div>
            </div>
            <div>
              <div className="flex justify-between text-sm mb-2">
                <span className="font-medium text-slate-700">ElevenLabs API Quota</span>
                <span className="text-indigo-600 font-medium">85% Remaining</span>
              </div>
              <div className="w-full bg-slate-100 rounded-full h-2">
                <div className="bg-indigo-500 h-2 rounded-full" style={{ width: '85%' }}></div>
              </div>
            </div>
            <div>
              <div className="flex justify-between text-sm mb-2">
                <span className="font-medium text-slate-700">Local Assets Validation</span>
                <span className="text-emerald-600 font-medium">Valid</span>
              </div>
              <p className="text-xs text-slate-500">2 Fonts loaded • 5 Background tracks loaded</p>
            </div>
            <div className="pt-4 border-t border-slate-100">
              <div className="flex items-center gap-2 text-sm text-slate-600">
                <div className="w-2 h-2 rounded-full bg-emerald-500"></div>
                FFmpeg detected
              </div>
              <div className="flex items-center gap-2 text-sm text-slate-600 mt-2">
                <div className="w-2 h-2 rounded-full bg-emerald-500"></div>
                ImageMagick detected
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
