import { Save, Key, User, Bell } from "lucide-react";

export function SettingsView() {
  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-slate-800">Settings</h2>
        <button className="flex items-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg font-medium transition-colors">
          <Save className="w-4 h-4" />
          Save Changes
        </button>
      </div>

      <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="grid grid-cols-1 md:grid-cols-4 min-h-[500px]">
          {/* Settings Sidebar */}
          <div className="md:col-span-1 border-b md:border-b-0 md:border-r border-slate-200 bg-slate-50 p-4 space-y-2">
            <button className="w-full flex items-center gap-3 px-3 py-2 bg-indigo-50 text-indigo-700 font-medium rounded-lg transition-colors">
              <Key className="w-5 h-5" />
              API Keys
            </button>
            <button className="w-full flex items-center gap-3 px-3 py-2 text-slate-600 hover:bg-slate-100 font-medium rounded-lg transition-colors">
              <User className="w-5 h-5" />
              Account
            </button>
            <button className="w-full flex items-center gap-3 px-3 py-2 text-slate-600 hover:bg-slate-100 font-medium rounded-lg transition-colors">
              <Bell className="w-5 h-5" />
              Notifications
            </button>
          </div>

          {/* Settings Content */}
          <div className="md:col-span-3 p-6 md:p-8 space-y-8">
            <div>
              <h3 className="text-xl font-bold text-slate-800 mb-2">API Configuration</h3>
              <p className="text-slate-500 text-sm mb-6">
                Update your API keys to connect to third-party services. These are securely stored in your local <code>.env</code> file.
              </p>

              <div className="space-y-6">
                <div className="space-y-2">
                  <label htmlFor="openai_key" className="block text-sm font-medium text-slate-700">
                    OpenAI API Key
                  </label>
                  <div className="relative">
                    <input 
                      type="password" 
                      id="openai_key"
                      defaultValue="sk-proj-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
                      className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-colors"
                    />
                    <button className="absolute right-3 top-1/2 -translate-y-1/2 text-sm text-indigo-600 font-medium hover:text-indigo-800">
                      Show
                    </button>
                  </div>
                  <p className="text-xs text-slate-500">Required for text generation and quote validation.</p>
                </div>

                <div className="space-y-2">
                  <label htmlFor="elevenlabs_key" className="block text-sm font-medium text-slate-700">
                    ElevenLabs API Key
                  </label>
                  <div className="relative">
                    <input 
                      type="password" 
                      id="elevenlabs_key"
                      defaultValue="xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
                      className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-colors"
                    />
                    <button className="absolute right-3 top-1/2 -translate-y-1/2 text-sm text-indigo-600 font-medium hover:text-indigo-800">
                      Show
                    </button>
                  </div>
                  <p className="text-xs text-slate-500">Required for high-quality text-to-speech voice generation.</p>
                </div>
                
                <div className="space-y-2">
                  <label htmlFor="voice_id" className="block text-sm font-medium text-slate-700">
                    Default ElevenLabs Voice ID
                  </label>
                  <input 
                    type="text" 
                    id="voice_id"
                    defaultValue="EXAVITQu4vr4xnSDxMaL"
                    className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-colors"
                  />
                  <p className="text-xs text-slate-500">The specific voice ID you want to use for the quotes.</p>
                </div>
              </div>
            </div>

            <hr className="border-slate-200" />

            <div>
              <h3 className="text-xl font-bold text-slate-800 mb-4">Automation Settings</h3>
              
              <div className="flex items-center justify-between p-4 bg-slate-50 border border-slate-200 rounded-lg">
                <div>
                  <h4 className="font-medium text-slate-800">Daily Auto-Post</h4>
                  <p className="text-sm text-slate-500">Automatically generate and post a video every day.</p>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input type="checkbox" className="sr-only peer" defaultChecked />
                  <div className="w-11 h-6 bg-slate-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-indigo-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-500"></div>
                </label>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
