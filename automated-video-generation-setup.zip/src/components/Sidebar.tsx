import { 
  LayoutDashboard, 
  MessageSquareQuote, 
  Video, 
  Settings, 
  Info,
  PlayCircle
} from "lucide-react";

interface SidebarProps {
  currentView: string;
  setCurrentView: (view: string) => void;
}

export function Sidebar({ currentView, setCurrentView }: SidebarProps) {
  const navItems = [
    { id: "dashboard", label: "Dashboard", icon: LayoutDashboard },
    { id: "quotes", label: "Quotes DB", icon: MessageSquareQuote },
    { id: "videos", label: "Videos", icon: Video },
    { id: "settings", label: "Settings", icon: Settings },
    { id: "quickstart", label: "Quick Start", icon: Info },
  ];

  return (
    <div className="w-64 h-screen bg-slate-900 text-slate-300 flex flex-col fixed left-0 top-0">
      <div className="p-6 border-b border-slate-800">
        <div className="flex items-center gap-3 text-white">
          <PlayCircle className="w-8 h-8 text-indigo-500" />
          <h1 className="text-xl font-bold">Auto-Poster</h1>
        </div>
      </div>
      <nav className="flex-1 p-4 space-y-2">
        {navItems.map((item) => (
          <button
            key={item.id}
            onClick={() => setCurrentView(item.id)}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
              currentView === item.id
                ? "bg-indigo-600 text-white"
                : "hover:bg-slate-800 hover:text-white"
            }`}
          >
            <item.icon className="w-5 h-5" />
            <span className="font-medium">{item.label}</span>
          </button>
        ))}
      </nav>
      <div className="p-4 border-t border-slate-800">
        <div className="bg-slate-800 rounded-lg p-4 flex flex-col items-center gap-2">
          <div className="w-3 h-3 rounded-full bg-emerald-500 animate-pulse"></div>
          <span className="text-sm font-medium">Auto Mode Active</span>
          <span className="text-xs text-slate-500">scheduler.py running</span>
        </div>
      </div>
    </div>
  );
}
